def play():
    '''
    int -> None
    Presents user with menu, exucutes user's choice function
    '''
    with open("NYT-bestsellers.txt") as textFile:
        bestsellers = [line.split('\t') for line in textFile]
    for x in bestsellers:
        if x[3][0] == " ":
            x[3] = x[3].strip()
        if x[1][0] == " ":
            x[3] = x[3].strip()
        
    answer = None
    print("=======================================================================")
    print("What would you like to do? Enter 1, 2, 3, 4, 5, 6, or Q to answer.")
    print("1: Look up year range")
    print("2: Look up month/year")
    print("3: Search for author")
    print("4: Search for title")
    print("5: Number of authors with at least x bestsellers")
    print("6: List y authors witht the most bestsellers")
    print("Q: Quit")
    print("=======================================================================")
    while answer != 'Q' or answer != 'q':
        answer = input("Answer (1, 2, 3, 4, 5, 6, or Q): ")
        try:
            if answer == 'Q' or answer == 'q':
                print("Thank you for searching.")
                return
        except:
            print("If your answer is not 'Q' or 'q', then it must be an integer.")
            print("Invalid input, please try again.")
        try:
            if int(answer) not in [1,2,3,4,5,6]:
                print("Invalid input, please try again.")
            if int(answer) == 1:
                years(bestsellers)
                input("Press enter to continue")
                print("=======================================================================")
                print("What would you like to do? Enter 1, 2, 3, 4, 5, 6, or Q to answer.")
                print("1: Look up year range")
                print("2: Look up month/year")
                print("3: Search for author")
                print("4: Search for title")
                print("5: Number of authors with at least x bestsellers")
                print("6: List y authors witht the most bestsellers")
                print("Q: Quit")
                print("=======================================================================")
            elif int(answer) == 2:
                 mnt_yr(bestsellers)
                 input("Press enter to continue")
                 print("=======================================================================")
                 print("What would you like to do? Enter 1, 2, 3, 4, 5, 6, or Q to answer.")
                 print("1: Look up year range")
                 print("2: Look up month/year")
                 print("3: Search for author")
                 print("4: Search for title")
                 print("5: Number of authors with at least x bestsellers")
                 print("6: List y authors witht the most bestsellers")
                 print("Q: Quit")
                 print("=======================================================================")
            elif int(answer) == 3:
                 author(bestsellers)
                 input("Press enter to continue")
                 print("=======================================================================")
                 print("What would you like to do? Enter 1, 2, 3, 4, 5, 6, or Q to answer.")
                 print("1: Look up year range")
                 print("2: Look up month/year")
                 print("3: Search for author")
                 print("4: Search for title")
                 print("5: Number of authors with at least x bestsellers")
                 print("6: List y authors witht the most bestsellers")
                 print("Q: Quit")
                 print("=======================================================================")
            elif int(answer) == 4:
                 title(bestsellers)
                 input("Press enter to continue")
                 print("=======================================================================")
                 print("What would you like to do? Enter 1, 2, 3, 4, 5, 6, or Q to answer.")
                 print("1: Look up year range")
                 print("2: Look up month/year")
                 print("3: Search for author")
                 print("4: Search for title")
                 print("5: Number of authors with at least x bestsellers")
                 print("6: List y authors witht the most bestsellers")
                 print("Q: Quit")
                 print("=======================================================================")
            elif int(answer) == 5:
                xbest(bestsellers)
                input("Press enter to continue")
                print("=======================================================================")
                print("What would you like to do? Enter 1, 2, 3, 4, 5, 6, or Q to answer.")
                print("1: Look up year range")
                print("2: Look up month/year")
                print("3: Search for author")
                print("4: Search for title")
                print("5: Number of authors with at least x bestsellers")
                print("6: List y authors witht the most bestsellers")
                print("Q: Quit")
                print("=======================================================================")
            elif int(answer) == 6:
                ybest(bestsellers)
                input("Press enter to continue")
                print("=======================================================================")
                print("What would you like to do? Enter 1, 2, 3, 4, 5, 6, or Q to answer.")
                print("1: Look up year range")
                print("2: Look up month/year")
                print("3: Search for author")
                print("4: Search for title")
                print("5: Number of authors with at least x bestsellers")
                print("6: List y authors witht the most bestsellers")
                print("Q: Quit")
                print("=======================================================================")
            elif int(answer) == int:
                print("Invalid input, please try again.")
        except:
            print("If your answer is not 'Q' or 'q', then it must be an integer.")
            print("Invalid input, please try again.") 
    
def years(bestsellers):
    '''
    (2-D List), int, int -> None
    Search (bestsellers) for books between (yearL) and (yearU), then prints books
    Precondition: (bestsellers) is of equal items in each row
    ''' 
    yearL = 0
    yearU = 0
    count = 0
    while yearL < 1000:
        try:
            yearL = int(input("Enter beginning year: "))
            if yearL < 1000:
                print("Please give a four digit integer for the year.")
        except:
            print("Beginning year must be an integer.")
    while yearU < 1000:
        try:
            yearU = int(input("Enter ending year: "))
            if yearU < 1000:
                print("Please give a four digit integer for the year.")
        except:
            print("End year must be an integer.")
    year_sort = sorted(bestsellers,key=lambda bestsellers: int(bestsellers[3][-4:]))
    for book in year_sort:
        date = int(book[3][-4:])
        if date >= yearL and date <= yearU:
            print(book[0] +','+ book[1] +','+ book[2] +','+ book[3] +','+ book[4])
            count += 1
    if count == 0:
        print("There are no books published between the years " + str(yearL) + " and " + str(yearU))
            
def mnt_yr(bestsellers):
    '''
    (2-D List), int, int -> String
    Searches (bestsellers) for books published in (month)/(year), then prints books
    Precondition: (bestsellers) is of equal items in each row
    '''
    month = 0
    year = 0
    count = 0
    while month not in range(1,13):
        try:
            month = int(input("Enter a month (as integer between 1-12): "))
            if month not in range(1,13):
                print("Invalid month, must be an integer, 1-12. Please try again.")
        except:
            print("Month must be an integer.")
    while year < 1000:
        try:
            year = int(input("Enter a year (as four digit integer): "))
            if year < 1000:
                print("Please give a four digit integer for the year.")
        except:
            print("Year must be an integer.")
    month_year_sort = sorted(bestsellers,key=lambda bestsellers: int(bestsellers[3][-4:]))
    for book in month_year_sort:
        cmonth = 0
        if '/' in book[3][0:2]:
            cmonth = int(book[3][0:1])
        else:
            cmonth = int(book[3][0:2])
        cyear = int(book[3][-4:])
        if month == cmonth and year == cyear:
            print(book[0] +','+ book[1] +','+ book[2] +','+ book[3] +','+ book[4])
            count += 1
    if count == 0:
        print("There are no books published in", str(month) +'/' + str(year))

def author(bestsellers):
    '''
    (2-D List), String -> None
    Searches (bestsellers) for (author), then prints (author)'s books
    Precondition: (bestsellers) is of equal item in each row
    '''
    count = 0
    author = input("Enter an author's name(or part of a name): ")
    for book in bestsellers:
        if author.lower() in book[1].lower():
            print(book[0] +','+ book[1] +','+ book[2] +','+ book[3] +','+ book[4])
            count += 1
    if count == 0:
        print("There are no books published with" + " '" + author + "' " + "as the author's name.")

def title(bestsellers):
    '''
    (2-D List), String -> None
    Searches (bestsellers) for (title), then prints books with (title) in their title
    Precondition: (bestsellers) is of equal items in each row
    '''
    count = 0
    title = input("Enter a title(or part of a title): ")
    for book in bestsellers:
        if title.lower() in book[0].lower():
            print(book[0] +','+ book[1] +','+ book[2] +','+ book[3] +','+ book[4])
            count += 1
    if count == 0:
        print("There are no books published with title that containts: ", title)
    
def xbest(bestsellers):
    '''
    (2-D List), int -> None
    Prints "authors,int" for authors with at least int number of bestsellers
    Precondition: (bestsellers) is of equal items in each row
    '''
    x = 0
    count = 0
    while x <= 0:
        try:
            x = int(input("Enter a positive integer: "))
            if x <= 0:
                print("Number must be at least one. Please try again.")
        except:
            print("Input invalid, must be an integer.")
    f = frequency(bestsellers)
    f = sorted(f,key=lambda f: f[1])
    print("The list of authors with at least", x, "NYT bestsellers is: ")
    for author in f:
        if author[1] >= x:
            print(str(author[0]) + ', ' + str(author[1]))
            count += 1
    if count == 0:
        print("There are no authors with", x, "NYT bestsellers.")
    
def ybest(bestsellers):
    '''
    (2-D List), int -> None
    Prints top (y) NYT bestselling authors
    Precondition: (bestsellers) of equal item in each row
    '''
    y = 0
    while y <= 0:
        try:
            y = int(input("Enter a positive integer: "))
            if y <= 0:
                print("Number must be at least one. Please try again.")
        except:
            print("Input invalid, must be an integer.")
    f = frequency(bestsellers)
    print("Top", y, "authors by the number of NYT bestsellers is: ")
    for i in range(1,y+1):
        print(str(i) + ". " + f[-i][0])
    
        
def frequency(bestsellers):
    '''
    (2-D List) -> (2-D List)
    Creates a list of authors from (bestsellers)
    Creates new 2-D list sorted by number of best selling books, each item is represented by [author, number of bestselling books]
    Preconditon: (bestsellers) is of equal items in each row
    '''
    authors = []
    for i in bestsellers:
        authors.append(i[1].strip())
    f = []
    count = 0
    while len(authors) > 0:
        i = authors[0]
        while i in authors:
             authors.remove(i)
             count += 1
        f.append([i,count])
        count = 0
    f = sorted(f,key=lambda f: f[1])
    return f

play()











