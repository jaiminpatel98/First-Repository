
a= input("Please input a list of numbers seperated by a comma: ")
l = list(eval(a))
def longest_run(_list):
    '''
    (list)->int
    takes list and prints the longest run of identical numbers in the list
    Precondition: user inputs at least two elements in the list
    '''
    result = None
    prev = None
    size = 0
    max_size = 0


    for i in _list:
        if i == prev:
            size += 1
            if size > max_size:
                
                max_size = size 
        else:
            size = 0
        prev = i
    print (max_size+1)    
    return max_size+1


longest_run(l)
