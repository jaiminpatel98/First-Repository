def two_length_run(l):
    '''
    (list)--> bool
    checks to see if list contains a pair of identical constective numbers in the list
    Precondition: assume user inputs at least two elemnets
    '''
    sl = len(l)
    for i in l:
        i = l.index(i)
        if (i + 1) < sl:
            if l[i] == l[(i+1)]:
                return True
        else:
            return False
s = input("Please input a list of numbers separated by commas:")
l = list(eval(s))
print(str(two_length_run(l)))
