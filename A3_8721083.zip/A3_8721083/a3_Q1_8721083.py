def count_pos(l):
    '''
    (list)-->str
    Takes list and return number of positive numbers in said list.
    Precondition: user inputs at least two elements
    '''
    count = 0
    for i in l:
        if i >= 0:
            count += 1
    return count
s = input("Please input a list of numbers separated by commas: ")
l = list(eval(s))
print("There are " + str(count_pos(l)) + " positive numbers in your list.")
