# In this implementation a card (that is not a 10) is represented
# by a 2 character string, where the 1st character represents a rank and the 2nd a suit.
# Each card of rank 10 is represented as a 3 character string, first two are the rank and the 3rd is a suit.

import random
from random import randint
def wait_for_player():
    '''()->None
    Pauses the program until the user presses enter
    '''
    try:
         input("\nPress enter to continue. ")
         print()
    except SyntaxError:
         pass


def make_deck():
    '''()->list of str
        Returns a list of strings representing the playing deck,
        with one queen missing.
    '''
    deck=[]
    suits = ['\u2660', '\u2661', '\u2662', '\u2663']
    ranks = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
    for suit in suits:
        for rank in ranks:
            deck.append(rank+suit)
    deck.remove('Q\u2663') # remove a queen as the game requires
    return deck

def shuffle_deck(deck):
    '''(list of str)->None
       Shuffles the given list of strings representing the playing deck    
    '''
    random.shuffle(deck)

#####################################

def deal_cards(deck):
     '''(list of str)-> tuple of (list of str,list of str)

     Returns two lists representing two decks that are obtained
     after the dealer deals the cards from the given deck.
     The first list represents dealer's i.e. computer's deck
     and the second represents the other player's i.e user's list.
     '''
     # COMPLETE THE BODY OF THIS FUNCTION ACCORDING TO THE DESCRIPTION ABOVE
     # YOUR CODE GOES HERE
     dealer = deck[0:25]
     human = deck[25:51]
     return (dealer, human)

def remove_pairs(l):
    '''
     (list of str)->list of str

     Returns a copy of list l where all the pairs from l are removed AND
     the elements of the new list shuffled

     Precondition: elements of l are cards represented as strings described above

     Testing:
     Note that for the individual calls below, the function should
     return the displayed list but not necessarily in the order given in the examples.

     >>> remove_pairs(['9♠', '5♠', 'K♢', 'A♣', 'K♣', 'K♡', '2♠', 'Q♠', 'K♠', 'Q♢', 'J♠', 'A♡', '4♣', '5♣', '7♡', 'A♠', '10♣', 'Q♡', '8♡', '9♢', '10♢', 'J♡', '10♡', 'J♣', '3♡'])
     ['10♣', '2♠', '3♡', '4♣', '7♡', '8♡', 'A♣', 'J♣', 'Q♢']
     >>> remove_pairs(['10♣', '2♣', '5♢', '6♣', '9♣', 'A♢', '10♢'])
     ['2♣', '5♢', '6♣', '9♣', 'A♢']
    '''

    no_pairs=[]

    # COMPLETE THE BODY OF THIS FUNCTION ACCORDING TO THE DESCRIPTION ABOVE
    # YOUR CODE GOES HERE
    l.sort()
    l.append([None])
    a = 1
    while a < len(l):
        if l[a-1][0] != l[a][0]:
            no_pairs.append(l[a-1])
            a += 1
        else:
            a += 2
        
    random.shuffle(no_pairs)
    return no_pairs

def print_deck(deck):
    '''
    (list)-None
    Prints elements of a given list deck separated by a space
    '''
    # COMPLETE THE BODY OF THIS FUNCTION ACCORDING TO THE DESCRIPTION ABOVE
    # YOUR CODE GOES HERE
    deck = ' '.join(deck)
    print(deck)
    
def get_valid_input(n):
     '''
     (int)->int
     Returns an integer given by the user that is at least 1 and at most n.
     Keeps on asking for valid input as long as the user gives integer outside of the range [1,n]
     
     Precondition: n>=1
     '''
     
     # COMPLETE THE BODY OF THIS FUNCTION ACCORDING TO THE DESCRIPTION ABOVE
     # YOUR CODE GOES HERE
     human_input = input("Give me an integer between 1 and " + str(n) + ": ")
     while True:
         if int(human_input) >= 1 and int(human_input) <= n:
             if int(human_input) == 1:
                 print("You chose my " + human_input + "st card")
             elif int(human_input) == 2:
                 print("You chose my " + human_input + "nd card")
             elif int(human_input) == 3:
                 print("You chose my " + human_input + "rd card")
             else:
                 print("You chose my " + human_input + "th card")
             return True
         else:
             human_input = input("Invalid answer. Give me an integer between 1 and " + str(n) + ": ")
     return human_input
def play_game():
     '''()->None
     This function plays the game'''
    
     deck=make_deck()
     shuffle_deck(deck)
     tmp=deal_cards(deck)
     dealer=tmp[0]
     human=tmp[1]


     print("Hello. My name is Robot and I am the dealer.")
     print("Welcome to my card game!")
     print("Your current deck of cards is:\n")
     
     print_deck(human)
     
     print("\nDo not worry. I cannot see the order of your cards")

     print("Now discard all the pairs from your deck. I will do the same.")
     wait_for_player()
     
     dealer=remove_pairs(dealer)
     human=remove_pairs(human)


     # CMPLETE THE play_game function HERE
     # YOUR CODE GOES HERE
     h = len(human)
     d = len(dealer)
     while True:
             h = len(human)
             d = len(dealer)
             n = len(dealer)
             if h == 0:
                 print("\nCongratulations! You beat me at Maiden.")
                 return True
             elif d == 0:
                 print("\nThat is unfortunate for you! I beat you at Maiden.")
                 return True
             print("*********************\n")
             print("Your turn\n")
             print("Your new hand is: \n")
             print_deck(human)
             print("\nI have " + str(n) + " cards. If 1 represents my first card and " + str(n) + " stands for my last card, \nwhich of my cards do you choose?")
             i = get_valid_input(n)
             print("The card you chose is " + dealer[(int(i)-1)])
             print("\nWith " + dealer[(int(i)-1)] + " added to your hand, your current hand is:\n")
             human.append((dealer[(int(i)-1)]))
             dealer.remove((dealer[(int(i)-1)]))
             print_deck(human)
             print("\nAfter discarding pairs and shuffling, your hand is: \n")
             human = remove_pairs(human)
             print_deck(human)
             
             wait_for_player()
             
             print("\n*********************\n")
             print("My turn\n")
             a = len(human)
             my_choice = randint(1,a)
             if my_choice == 1:
                 print("I chose your " + str(my_choice) + "st card")
             elif my_choice == 2:
                 print("I chose your " + str(my_choice) + "nd card")
             elif my_choice == 3:
                 print("I chose your " + str(my_choice) + "rd card")
             else:
                 print("I chose your " + str(my_choice) + "th card")
             dealer.append((human[(my_choice - 1)]))
             human.remove((human[(my_choice - 1)]))
             dealer = remove_pairs(dealer)

             wait_for_player()

     



# main
play_game()
