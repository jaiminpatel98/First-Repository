def digit_sum(n):
    ''' (int)->int '''
    if n == 0:
        return 0
    else:
        return (n%10) + digit_sum(n//10)

def digital_root(n):
    ''' (int) -> int '''
    n1 = digit_sum(n)
    if n1 < 10:
        return print(n1)
    digital_root(n1)

digital_root(1969)
 
