class Point:
    'class that represents a point in the plane'

    def __init__(self, xcoord=0, ycoord=0):
        ''' (Point,number, number) -> None
        initialize point coordinates to (xcoord, ycoord)'''
        self.x = xcoord
        self.y = ycoord

    def setx(self, xcoord):
        ''' (Point,number)->None
        Sets x coordinate of point to xcoord'''
        self.x = xcoord

    def sety(self, ycoord):
        ''' (Point,number)->None
        Sets y coordinate of point to ycoord'''
        self.y = ycoord

    def get(self):
        '''(Point)->tuple
        Returns a tuple with x and y coordinates of the point'''
        return (self.x, self.y)

    def move(self, dx, dy):
        '''(Point,number,number)->None
        changes the x and y coordinates by dx and dy'''
        self.x += dx
        self.y += dy

    def __eq__(self, other):
        '''(Point,Point)->bool
        Returns True if self and other have the same coordinates'''
        return self.x == other.x and self.y == other.y
    def __repr__(self):
        '''(Point)->str
        Returns canonical string representation Point(x, y)'''
        return 'Point('+str(self.x)+','+str(self.y)+')'
    def __str__(self):
        '''(Point)->str
        Returns nice string representation Point(x, y).
        In this case we chose the same representation as in __repr__'''
        return 'Point('+str(self.x)+','+str(self.y)+')'

class Rectangle(Point):
    'class that represents creation of rectangles'

    def __init__(self, point1=(0,0), point2=(0,0), colour=None):
        ''' (Point, Point, Colour) -> None
        initiallize bottom-left and top-right points, and colour'''
        self.point1 = point1
        self.point2 = point2
        self.colour = colour

    def __repr__(self):
        ''' (Point, Point, Colour) -> str
        Returns canonical string representation of Rectangle(point1, point2, colour)'''
        return 'Rectangle(' + str(self.point1) + ',' + str(self.point2) + ',' + "'" + str(self.colour) + "'" + ')'

    def __eq__(self,other):
        ''' (Point, Point) -> bool
        Returns True if self and other have the same coordinates'''
        return self.point1 == other.point1 and self.point2 == other.point2
    
    def __str__(self):
        ''' (Point, Point, Colour) -> str
        Returns string representation in the same format as seen in __repr__'''
        return "I am a " + str(self.colour) + " rectangle with bottome left corner at " + str(self.point1) + " and top right corner at " + str(self.point2)

    def move(self, dx, dy):
        ''' (xcoord, ycooord, xcoord, ycoord) -> None
        Moves each point to a new location deteerminded by method parameters'''
        self.point1.move(dx, dy)
        self.point2.move(dx, dy)

    def get_bottom_left(self):
        ''' (Rectangle) -> Point
        Returns bottom-left point of rectangle'''
        return self.point1

    def get_top_right(self):
        ''' (Point) -> Point
        Returns top-right point of rectangle'''
        return self.point2

    def get_colour(self):
        ''' (Colour) -> colour
        Returns colour of rectangle'''
        return self.colour

    def intersect(self, other):
        ''' (Rectangle, Rectangle) -> bool
        Returns True if the rectangles intersect and returns False otherwise'''
        if (self.point1.x > other.point2.x) or (other.point1.x > self.point2.x):
            return False

        if (self.point2.y < other.point1.y) or (other.point2.y < self.point1.y):
            return False

        return True

    def contains(self, x, y):
        ''' (Rectangle, xcoord, ycoord) -> bool
        Returns True if rectangle contains Point(xcoood,ycoord) and returns False otherwise'''
        if x >= self.point1.x and x <= self.point2.x and y >= self.point1.y and y <= self.point2.y:
            return True

        return False

    def reset_colour(self, color):
        ''' (Rectangle, colour) -> None
        Changes the colour of the Rectangle'''
        self.colour = color
        
    def get_perimeter(self):
        ''' (Rectangle) -> int
        Returns the perimeter of the Rectangle'''
        return abs(self.point2.x - self.point1.x)*2 + abs(self.point2.y - self.point1.y)*2

    def get_area(self):
        ''' (Rectangle) -> int
        Returns the area of the Rectangle'''
        return abs(self.point2.x - self.point1.x)*abs(self.point2.y - self.point1.y)

class Canvas:
    def __init__(self, rectangles = []):
        ''' (Rectangle, List) -> None
        Initialize list of Rectangles'''
        self.rectangles = rectangles

    def __repr__(self):
        ''' (Canvas) -> str
        Returns connical representation of Canvas(Rectangles)'''
        return "Canvas(" + str(self.rectangles) + ")"

    def __len__(self):
        ''' (Canvas) -> int
        Returns the lenght of list of rectangles'''
        return len(self.rectangles)
        
    def add_one_rectangle(self, rectangle):
        ''' (Canvas, List) -> None
        Appends rectangle to list of rectangles'''
        self.rectangles.append(rectangle)

    def count_same_colour(self, colour):
        ''' (Canvas, colour) -> int
        Counts the amount of retangles that share the same colour'''
        count = 0
        for i in self.rectangles:
            if colour in i.colour:
                count += 1
        return count

    def total_perimeter(self):
        ''' (Canvas) -> int
        Returns the total perimeter of all rectangles in Canvas'''
        total = 0
        for i in self.rectangles:
            total += i.get_perimeter()
        return total

    def min_enclosing_rectangle(self):
        ''' (Canvas) -> Rectangle
        Returns a rectangle with minimum bottom-left and top-right corners that enclose all rectangles in canvas'''
        minx = 100000000
        miny = 100000000
        maxx = -100000000
        maxy = -100000000
        for i in self.rectangles:
            if i.point1.x < minx:
                minx = i.point1.x
                
            if i.point1.y < miny:
                miny = i.point1.y

            if i.point2.x > maxx:
                maxx = i.point2.x

            if i.point2.y > maxy:
                maxy = i.point2.y
        return Rectangle(Point(minx, miny), Point(maxx, maxy), 'black')

    def common_point(self):
        ''' (Canvas) -> bool
        Returns True if all rectangles in canvas intersect with one another and False otherwise'''
        count=0
        for i in self.rectangles:
            for j in self.rectangles:
                if i.intersect(j):
                    count += 1
                else:
                    return False
        return True

        
        
            
        
    


























    

    
