def largest_34(a):
    a.sort()
    return a[-3] + a[-4]

def largest_third(a):
    third_sum = 0
    a.sort()
    for i in range(len(a)//3*2, len(a)):
        third_sum += a[-i]

    return third_sum
def third_at_least(a):
    a.sort()
    for i in range(len(a)-len(a)//3):
        if (a[i] == a[i+len(a)//3]):
            return a[i]
    return False

def sum_tri(a, x):
    a.sort()
    for i in range(len(a)):
        for j in range(i, len(a)):
            for k in range(j, len(a)):
                if (a[i] + a[j] + a[k]) == x:
                    return a[i], a[j], a[k]
    return False
