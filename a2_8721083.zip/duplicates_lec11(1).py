import random

# 1st strategy: compare every element to every other element. 
# this solution is incorrect. why?
def duplicates_wrong(lst):
     '''(list)->bool
     Returns True if there are duplictes in the list
     In other words if the contains at least 2 elements that are the same'''
     for i in range(len(lst)):
          for j in range (len(lst)):
               if lst[i]==lst[j]:
                    return True
     return False

# The above is wrong, because we have to make sure that we do not
# compare two elements that are in the same position. 
# Here is a corrected solution:

def duplicates_fixed(lst):
     '''lst -> bool
        Returns True if the list contains at least 2 elements that are the same
     '''
     for i in range(len(lst)):
          for j in range (len(lst)):
               if lst[i]==lst[j] and i!=j: # fix here
                    return True
     return False

# duplicates better solution: compare each element x[i] with everything that comes after it
# that effectively compares all possible pairs of elements of l
def duplicates(lst):
     '''lst -> bool
        Returns True if the list contains at least 2 elements that are the same
     '''
     for i in range(len(lst)-1):
          for j in range (i+1, len(lst)):
               if lst[i]==lst[j]:
                    return True
     return False

# What is the number of operations of the above solution(s) roughly in the worst case
# (for example, when there are no duplicates)?
#
# In both cases it is roughly O(n^2) where n is the lenght of the list, i.e. n=len(l).
# O stand for "roughly" -- meaning we ignore constants and lower order terms.

# much better solution than the two above:
def duplicates_via_sort(lst):
     '''lst -> bool
        Returns True if the list contains at least 2 elements that are the same
     '''
     lst.sort()
     for i in range(len(lst)-1):
          if lst[i]==lst[i+1]:
               return True
     return False

# The above solution via sorting does roughly O(n log n) operations
# since the best sorting algoritms do roughly O(n log n) operations


# experiment:

#this creates a list and and fills it will numbers 0, 1, 2 .. up to 10 million
size=10000000
x=[i for i in range(size)]
random.shuffle(x)

# thus the list has no duplicates and both calls below should return False.
# the first one returns False in about 10-15 seconds
answer=duplicates_via_sort(x)
print(answer)

random.shuffle(x)
# this call will run for hours before returning False
# -- well I did not get to see it terminating but it will eventually  
answer=duplicates(x)
print(answer)


