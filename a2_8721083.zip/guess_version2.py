import random

# Note that it is always possible to win this game with 10 guesses. Do you know why?
def guessing_game_v2():
     '''()->None
     Plays a simple guessing game. A player has 10 tries to guess an integer
     that a program picks in the range [1, 1000]
     '''
 
     print("I am thiniking of a number in the set 1, 2, 3 .... 1000")
     x=random.randint(1,1000)
     print("I will never tell ...")

     tries=10 
     guess=-1 # set variable guess to something outside of 1-1000 range
              # so that the quess variable in the next line would not be undefined
     while tries>0 and guess!=x:
          guess=int(input("Try and guess: "))
          tries=tries-1
          if guess<x:
               print("Wrong!! Too low!!!", tries, "guesses left")
          elif guess>x: 
               print("Wrong!! Too high!!!", tries, "guesses left")

     if guess==x:
          print("You win. Great work!!")
     else:
          print("You are not a very good guesser. Go read up on binary search")
          print("The number was", x)
 
# main
guessing_game_v2()
