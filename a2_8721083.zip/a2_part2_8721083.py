##################################################################
 # Question 1
###################################################################
def size_format(b):
    '''
    (int)-->str
    takes b(byte) and converts to most conveinient  byte units
    precondition: b(byte) is negative program proompts user to get new hard disk
    '''
    answer1="buy a new hard disk"
    answer2=str(b)
    if b < 0:
        return answer1
    elif b < 1000:
        return answer2
    elif b >=1000 and b < 1000000:
        b = b / 1000
        answer2=str(b)+"KB"
        b = round(b,1)
        return answer2
    elif b >= 1000000 and b < 1000000000:
        b = b / 1000000
        b = round(b,1)
        answer2=str(b)+"MB"
        return answer2
    elif b >= 1000000000 and b < 1000000000000:
        b = b / 1000000000
        b = round(b,1)
        answer2=str(b)+"GB"
        return answer2
    else:
        b = b/1000000000000
        b = round(b,1)
        answer2=str(b)+"TB"
        return answer2
##################################################################
 # Question 2
###################################################################
def add_article(s):
    '''
    (str)-->str
    takes s(country) and adds 'la' if feminine, 'le' if masuline, or 'les' if plural
    precondition: s(country) starts with capital letter
    '''
    s=str(s)
    if (s == 'Etats-Unis') or (s == 'Pay-bas'):
        s="les " + s
        return s
    elif (s == 'Cambodge') or (s == 'Mexique') or (s == 'Mozambique') or (s == 'Zaire') or (s == 'zimbabwe'):
        s="le " + s
        return s
    elif s[0] in 'AEIOU':
        s="l'"+s
        return s
    elif s[-1] is ('e'):
        s="la "+ s
        return s
    else:
        s="le "+ s
        return s
##################################################################
 # Question 3
###################################################################
def factorial(n):
    '''
    (int)-->int
    takes n(positive int) and finds the factorial of that number
    precondition: n is positibe
    '''
    factorial1 = 1

    for i in range(1,n+1):
        factorial1=factorial1*i
    return factorial1
##################################################################
 # Question 4
###################################################################
def special_count(l):
    '''
    (list)-->int
    finds number of int in l(list) that respect the rules of special numbers
    precondition: all elements in l are positive
    '''
    counter = 0
    for i in l:
        if (i>=0):
            if i%100==0:
                if i%400==0:
                    counter+=1
            elif i%4==0:
                counter+=1

    return counter
##################################################################
 # Question 5
###################################################################
def vote():
    '''
    (str)-->str
    assess the outcome of a vote and prompts the user with string according to the percentage majorirty of votes for yes
    precondition: votes that are abstained do not count toward outcome of the proposal
    '''
    v = input("Enter the yes, no, abstained votes one by one then press enter: ")
    v = v.lower()
    vyes = 0
    vno = 0
    v = v.replace("abstained", "")
    vyes = vyes + v.count('y') 
    vno = vno + v.count('n')
    answer="proposal passes unanimously"
        
    vote_final=vyes/(vyes+vno)
    if vote_final == 1:
        return answer
    elif vote_final >= (2/3):
        answer="proposal passes with super majority"
        return answer
    elif vote_final >= (1/2):
        answer="proposal passes with simple majority"
        return answer
    else:
        answer="proposal fails"
        return answer
##################################################################
 # Question 6
###################################################################
from random import randint
def stats_v1(n):
    '''
    int-->(str,int)
    takes n(int) and generate n random numbers between -100 and 100
    then stores them in a list
    then finds the minimum of the random numbers and the average of random numbers
    precondition: n is positive
    '''
    rcount = 0
    rlist = []
    for rand in range(n):
        rand = randint(-100,100)
        rlist.append(rand)
        rcount += rand
    ravg = rcount/n
    print("The minimuma nd average of these numbers: ")
    print(rlist, end=' ')
    print("is", min(rlist), "and", ravg)
    
def stats_v2(n):
   '''
    int-->(str,int)
    takes n(int) and generate n random numbers between -100 and 100
    then finds the minimum of the random numbers and the average of random numbers
    precondition: n is positive
    '''
    minimum = 9999999
    rcount = 0
    print("The mimimum and average of these numbers: ")
    for rand in range(n):
        rand = randint(-100,100)
        rcount += rand
        print(rand, end=' ')
        if minimum > rand:
            minimum = rand
    ravg = rcount/n
    print("is", minimum, "and", ravg)
#################################################################
# Question 7
###################################################################
def emphasize(s):
    '''
    (str)-->str
    puts spaces between every character and space in s(string)
    precondition: s is a string
    '''
    smod=(s.replace(""," ")[1: -1])
    return smod
#################################################################
 # Question 8
###################################################################
def crypto(s):
    '''
    (str)-->str
    takes s(string) and encrypts it by folowing this order of character with repects to the original string
    last, first, second-last, second, third from the end, third etc
    precondition: s is a string
    '''
    slist = list(s)
    for i in range(0,len(s), 2):
        t = slist.pop()
        slist.insert(i, t)
    answer=(''.join(slist))
    return answer
#################################################################
 # Question 9
###################################################################
def stranger_things(l1,l2):
    '''
    (list,list)-->bool
    takes l1 and l2 (lists), and compares their elements
    if they have the same number of elements, and the even indicies match the other,
    and the odd indicies match each other, the program returns True
    otherwise the function returns False
    precondition: two non empty lists
    '''
    count1 = 0
    count2 = 0
    sizel1 = len(l1)
    sizel2 = len(l2)
    for t in range(0,len(l1)):
        if sizel1 == sizel2:
            if (t%2==0) and (l1[t] == l2[t]):
                count1+=1
            elif (l1[t] != l2[t]):
                count2+=1
            else:
                return False
        else:
            return False
    return True

        
        
        
    
        
    
    
        






















                            
