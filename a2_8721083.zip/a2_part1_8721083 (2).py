from random import randint
print("How many qustions would you like to be tested on?")
n = input("Enter a non negative integer for the answer: ")
n = int(n)
print("This program will test you on", n, "questions...")
print("0) Addition")
print("1) Muultiplication")
opr = input("Please choose an operation (0 or 1): ")
opr = int(opr)

def perform_test():
    mark_counter = 0
    if opr == 0:
        print("Please answer the following addition test:")
    elif opr == 1:
        print("Please answer the following multiplication test:")
    else:
        print("Please choose again")
    if opr == 0:
        for ans in range(n):
            n1 = randint(0,9)
            n2 = randint(0,9)
            ans = input(str(n1) + ' + ' + str(n2) + ' = ')
            
            if (n1 + n2) == int(ans):
                print("Correct!")
                mark_counter += 1
            else:
                print("Incorret!")
    elif opr == 1:
            for ans2 in range(n):
                n1 = randint(0,9)
                n2 = randint(0,9)
                ans2 = input(str(n1) + ' * ' + str(n2) + ' = ')

                if (n1 * n2) == int(ans2):
                    print("Correct!")
                    mark_counter += 1
                else:
                    print("Incorrect!")
    if (mark_counter / n) >= .8:
        print("Well done! Congratualtions.")
    elif ((mark_counter / n) >= .6) and ((mark_count / n) < .8):
        print("Not too bad but please study and practice some more.")
    else:
        print("Please study more and ask your teacher for help.")
perform_test()
    
    
    
  
