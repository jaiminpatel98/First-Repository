# Course: ITI 1120
# Assignment number:1
# Patel, Jaimin
# 8721083
import turtle

###################################################################
 # Question 1
###################################################################
def lbs2kg(w):
    '''
    int->int
    converts pounds to kilograms
    '''
    kg = w/2.21
    return kg
###################################################################
 # Question 2
###################################################################
def id_formater(fn, ln, appelation, city, year):
    '''
    str and int -> str
    takes user  info and creates an ID
    '''
    id_add=appelation+'. '+ln+','+fn+'('+city+','
    id_add+=str(year)
    id_add+=')'
    return str(id_add)
###################################################################
 # Question 3
###################################################################
def limerick_maker():
    '''
    str->str
    creates a limerick based on user input
    '''
    name = input("What is your name? ")
    place = input("Where were you born? ")
    print("There was a man like an ugly bear, His name was ")
    print(name + ", he claims to know all")
    print("He came from a place called " + place)
    print("but everyone knows it's all a lie")
###################################################################
 # Question 4
###################################################################
def id_formater_display():
    '''
    str->str
    formats the ID created in Q2
    '''
    fn = input("What is your first name? ")
    ln = input("What is your last name? ")
    app = input("What is your appelation? ")
    pob = input("What is your place of birth? ")
    yob = input("What is your year of birth? ")
    ID = print(id_formater(fn, ln, app, pob, yob))
###################################################################
 # Question 5
###################################################################
def l2loz(w):
    '''
    int->int
    '''
    l = w//1
    w %= 1
    o = w*16
    return int(l), o
###################################################################
 # Question 6
###################################################################
def draw_soccer_field():
    s=turtle.Screen()
    t=turtle.Turtle()
    t.pendown()
    t.setheading(90)
    t.forward(300)
    t.right(90)
    t.forward(400)
    t.right(90)
    t.forward(150)
    t.right(90)
    t.forward(150)
    t.left(90)
    t.forward(300)
    t.left(90)
    t.forward(150)
    t.left(90)
    t.forward(300)
    t.penup()
    t.goto(400, 50)
    t.left(90)
    t.pendown()
    t.forward(50)
    t.left(90)
    t.forward(100)
    t.left(90)
    t.forward(50)
    t.penup()
    t.goto(0,0)
    t.setheading(270)
    t.pendown()
    t.forward(300)
    t.left(90)
    t.forward(400)
    t.left(90)
    t.forward(150)
    t.penup()
    t.goto(0,300)
    t.setheading(180)
    t.pendown()
    t.forward(400)
    t.left(90)
    t.forward(150)
    t.left(90)
    t.forward(150)
    t.right(90)
    t.forward(300)
    t.right(90)
    t.forward(150)
    t.right(90)
    t.forward(300)
    t.penup()
    t.goto(-400, 50)
    t.pendown()
    t.right(90)
    t.forward(50)
    t.right(90)
    t.forward(100)
    t.right(90)
    t.forward(50)
    t.penup()
    t.goto(-400, -150)
    t.pendown()
    t.setheading(270)
    t.forward(150)
    t.left(90)
    t.forward(400)
    t.penup()
    t.goto(100,0)
    t.setheading(90)
    t.pendown()
    t.circle(100)
    t.penup()
    t.goto(0,0)
    t.pendown()
    t.dot(10)
    t.penup()
    t.goto(-300,0)
    t.pendown()
    t.dot(10)
    t.penup()
    t.goto(300,0)
    t.pendown()
    t.dot(10)
    t.penup()
    t.goto(250, 75)
    t.setheading(180)
    t.pendown()
    t.circle(75, 180)
    t.penup()
    t.goto(-250,-75)
    t.setheading(0)
    t.pendown()
    t.circle(75, 180)
###################################################################
 # Question 7
###################################################################
def median3(num1, num2, num3):
    '''
    int>str
    findng median in 3 medians
    '''
    med = str(num1) + " is a median: " + str(not num1 > num3 and num1 > num2 or num1 < num3 and num1 < num2)
    med += str(num2) + " is a median: " + str(not num2 > num3 and num2 > num1 or num2 < num3 and num2 < num1)
    med += str(num3) + " is a median: " + str(not num3 > num2 and num3 > num1 or num3 < num2 and num3 < num1)
    return str(med)
###################################################################
 # Question 8
###################################################################
def below_parabola(a,b,p,q):
    '''
    int->int
    checks if point is below the parabola
    '''
    blw = q <=(a*(p**2)+b)
    return blw
###################################################################
 # Question 9
###################################################################
def projected_grade(a1,A1,a2,A2,m,M):
    '''
    int->int
    calculates the projected grade of a student
    '''
    as1 = (a1/A1)*0.05
    as2 = (a2/A2)*0.05
    as3 = (a1 + a2)/2
    as3t = (A1 + A2)/2
    ast = as1 + as2 + (as3/as3t)*0.05
    ex = (m/M)*0.50
    mx = (m/M)*0.35
    total_mark = (ast + mx + ex)*100
    return total_mark
###################################################################
 # Question 10
###################################################################
def projected_grade_v2():
    '''
    int->int
    '''
    a1 = int(input("What was your mark on the first assignment? "))
    A1 = int(input("How many marks was assignment 1 out of? "))
    a2 = int(input("What was your mark on the second assignment? "))
    A2 = int(input("How many marks was assignment 2 out of? "))
    m = int(input("What was your mark on the midterm? "))
    M = int(input("How many marks was the midterm out of? "))
    as1 = a1/A1
    as2 = a2/A2
    as3 = (a1 + a2)/2
    as3t = (A1 + A2)/2
    ast = (a1 + a2 + as3)/(A1 + A2 + as3t)
    ex = m/M
    exmt = (m*.35) + (m*.5)
    total_mark2 = (ast*.15 + ex*.35 + ex*.5)*100
    if exmt < 50:
        print(min(projected_grade(a1,A1,a2,A2,m,M),exmt))
    else:
        return total_mark2
    
    
###################################################################
 # Question 11
###################################################################
def change_to_coins(amount):
    amount = amount*100.0
    amount = round(amount,2)
    q = amount // 25
    amount = amount%25
    d = amount // 10
    amount  = amount%10
    n = amount // 5
    amount = amount%5
    p = amount // 1
    return q,d,n,p
    
    























 
